package com.example.appprova3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CatalogoActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private LinearLayout layoutProdutos;
    private Button btnWhatsapp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogo);

        layoutProdutos = findViewById(R.id.layout_produtos);
        btnWhatsapp = findViewById(R.id.btn_whatsapp);

        databaseHelper = new DatabaseHelper(this);

        // Carregar produtos do banco de dados
        loadProducts();

        // Botão para fazer pedido no WhatsApp
        btnWhatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String numeroWhatsapp = "55+999999999"; // Coloque o número correto aqui
                String mensagem = "Gostaria de fazer um pedido!";
                String url = "https://api.whatsapp.com/send?phone=" + numeroWhatsapp + "&text=" + mensagem;
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });
    }

    private void loadProducts() {
        Cursor cursor = databaseHelper.getProducts();
        while (cursor.moveToNext()) {
            String nomeProduto = cursor.getString(cursor.getColumnIndexOrThrow("nome_produto"));
            String descricaoProduto = cursor.getString(cursor.getColumnIndexOrThrow("descricao"));
            double precoProduto = cursor.getDouble(cursor.getColumnIndexOrThrow("preco"));

            // Adiciona o produto à tela
            TextView tvProduto = new TextView(this);
            tvProduto.setText(nomeProduto + "\n" + descricaoProduto + "\nR$" + precoProduto);
            layoutProdutos.addView(tvProduto);
        }
        cursor.close();
    }
}
