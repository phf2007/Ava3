package com.example.appprova3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroActivity extends AppCompatActivity {

    private EditText etNome, etEmail, etSenha, etTelefone;
    private Button btnSalvar;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        etNome = findViewById(R.id.et_nome);
        etEmail = findViewById(R.id.et_email);
        etSenha = findViewById(R.id.et_senha);
        etTelefone = findViewById(R.id.et_telefone);
        btnSalvar = findViewById(R.id.btn_salvar);

        databaseHelper = new DatabaseHelper(this);

        // Salvar os dados do usuário
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = etNome.getText().toString();
                String email = etEmail.getText().toString();
                String senha = etSenha.getText().toString();
                String telefone = etTelefone.getText().toString();

                if (databaseHelper.addUser(nome, email, senha, telefone)) {
                    Toast.makeText(CadastroActivity.this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(CadastroActivity.this, "Erro no cadastro. Tente novamente.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}