package com.example.appprova3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Nome do banco de dados
    private static final String DATABASE_NAME = "appburger.db";
    private static final int DATABASE_VERSION = 1;

    // Tabelas
    private static final String TABLE_USERS = "usuarios";
    private static final String TABLE_PRODUCTS = "produtos";

    // Colunas da tabela de usuários
    private static final String COL_USER_ID = "id_usuario";
    private static final String COL_USER_NAME = "nome";
    private static final String COL_USER_EMAIL = "email";
    private static final String COL_USER_PASSWORD = "senha";
    private static final String COL_USER_PHONE = "telefone";

    // Colunas da tabela de produtos
    private static final String COL_PRODUCT_ID = "id_produto";
    private static final String COL_PRODUCT_NAME = "nome_produto";
    private static final String COL_PRODUCT_DESCRIPTION = "descricao";
    private static final String COL_PRODUCT_PRICE = "preco";
    private static final String COL_PRODUCT_CATEGORY = "categoria";

    // Script para criar a tabela de usuários
    private static final String CREATE_TABLE_USERS =
            "CREATE TABLE " + TABLE_USERS + "("
                    + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COL_USER_NAME + " TEXT,"
                    + COL_USER_EMAIL + " TEXT,"
                    + COL_USER_PASSWORD + " TEXT,"
                    + COL_USER_PHONE + " TEXT" + ")";

    // Script para criar a tabela de produtos
    private static final String CREATE_TABLE_PRODUCTS =
            "CREATE TABLE " + TABLE_PRODUCTS + "("
                    + COL_PRODUCT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COL_PRODUCT_NAME + " TEXT,"
                    + COL_PRODUCT_DESCRIPTION + " TEXT,"
                    + COL_PRODUCT_PRICE + " REAL,"
                    + COL_PRODUCT_CATEGORY + " TEXT" + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Criação das tabelas
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_PRODUCTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Atualização das tabelas, se necessário
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCTS);
        onCreate(db);
    }

    // Método para inserir usuário
    public boolean addUser(String nome, String email, String senha, String telefone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USER_NAME, nome);
        values.put(COL_USER_EMAIL, email);
        values.put(COL_USER_PASSWORD, senha);
        values.put(COL_USER_PHONE, telefone);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;  // Retorna true se a inserção foi bem-sucedida
    }

    // Método para verificar login
    public boolean checkUser(String email, String senha) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USER_EMAIL + "=? AND " + COL_USER_PASSWORD + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{email, senha});
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;  // Usuário encontrado
        }
        cursor.close();
        return false;  // Usuário não encontrado
    }

    // Método para adicionar produtos (usado inicialmente)
    public void addProducts() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // Exemplo de produtos (Hambúrgueres)
        values.put(COL_PRODUCT_NAME, "Burger 1");
        values.put(COL_PRODUCT_DESCRIPTION, "Pão, Carne, Alface, Tomate");
        values.put(COL_PRODUCT_PRICE, 39.90);
        values.put(COL_PRODUCT_CATEGORY, "Hambúrguer");
        db.insert(TABLE_PRODUCTS, null, values);

        values.put(COL_PRODUCT_NAME, "Burger 2");
        values.put(COL_PRODUCT_DESCRIPTION, "Pão, Carne, Queijo, Bacon");
        values.put(COL_PRODUCT_PRICE, 44.30);
        values.put(COL_PRODUCT_CATEGORY, "Hambúrguer");
        db.insert(TABLE_PRODUCTS, null, values);

        // Exemplo de produtos (Bebidas)
        values.put(COL_PRODUCT_NAME, "Coca-Cola");
        values.put(COL_PRODUCT_DESCRIPTION, "Lata 350ml");
        values.put(COL_PRODUCT_PRICE, 5.00);
        values.put(COL_PRODUCT_CATEGORY, "Bebida");
        db.insert(TABLE_PRODUCTS, null, values);

        values.put(COL_PRODUCT_NAME, "Fanta");
        values.put(COL_PRODUCT_DESCRIPTION, "Lata 350ml");
        values.put(COL_PRODUCT_PRICE, 3.90);
        values.put(COL_PRODUCT_CATEGORY, "Bebida");
        db.insert(TABLE_PRODUCTS, null, values);
    }

    // Método para carregar todos os produtos do banco
    public Cursor getProducts() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_PRODUCTS, null);
    }
}